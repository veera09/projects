package com.capgemini.doctors.dao;

public interface IQueryMapper {
	static String INSERT_QUERY = 
	"INSERT INTO DOCTORAPPOINTMENT(appointmentId,patientName,phoneNumber,dateOfAppointment,email,age,gender,problemName,doctorName,appointmentStatus)"
	+ "VALUES(appoint_seq.nextval,?,?,sysdate+2,?,?,?,?,?,?)";
	static String SEARCH_DOCTOR = "SELECT DOCTORNAME FROM PROBLEMLIST WHERE PROBLEM = ?";
	static String GET_APPOINTMENT_DETAILS = "SELECT patientName,appointmentStatus,doctorName,dateOfAppointment FROM DOCTORAPPOINTMENT where appointmentId = ?";
	static String GET_APPOINTMENT_ID = "SELECT appoint_seq.CURRVAL FROM DUAL";
	static String GET_PROBLEM_NAMES ="SELECT PROBLEM FROM PROBLEMLIST";
}







