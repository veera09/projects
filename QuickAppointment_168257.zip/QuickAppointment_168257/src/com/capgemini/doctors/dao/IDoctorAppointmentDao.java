package com.capgemini.doctors.dao;

import java.util.List;


import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;

public interface IDoctorAppointmentDao {
	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorsException;
	//public String getDoctorName(String probName) throws DoctorsException;
	DoctorAppointment getAppointmentDetails(int appointmentId) throws DoctorsException;
	//public List<String> getProblemNames() throws DoctorsException;
	public int getAppointmentId() throws DoctorsException;

}
