package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DoctorsException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client {
	private static Scanner in;

	private static IDoctorAppointmentService ida = new DoctorAppointmentService();

	public static void main(String[] args) throws DoctorsException {

		in = new Scanner(System.in);
		System.out.println(" \nWelcome to mobile purchase portal\n");
		while (true) {
			System.out.println(" \nEnter your choice:\n");
			System.out.println(" 1.Book Doctor Appointement\n");
			System.out.println(" 2.View Doctor Appointement\n");
			System.out.println(" 3.Exit\n");
			int choice = in.nextInt();
			switch (choice) {

			case 1:
				getInputs();
				break;

			case 2:
				System.out.println("Enter your Appointment ID");
				int ID = in.nextInt();
				// ida.getAppointmentDetails(ID);
				viewAppointment(ID);
				break;

			case 3:
				System.out.println("\n\nThank you");
				System.exit(0);

			}

		}

	}

	private static void getInputs() throws DoctorsException {

		String patientName;
		String PhoneNumber;
		String email;
		int age;
		String gender;
		String problemName;
		String status = null;

		DoctorAppointment doctorAppointment = new DoctorAppointment();

		while (true) {
			in.nextLine();
			System.out.println("Enter patient name");

			patientName = in.nextLine();

			if (ida.validatePatientName(patientName)) {
				
				doctorAppointment.setPatientName(patientName);

				
				break;
			} else {
				System.out.println("Invalid patient name");
			}
		}

		while (true) {
			System.out.println("Enter phone number");

			PhoneNumber = in.next();

			if (ida.validatePhoneNumber(PhoneNumber)) {
				doctorAppointment.setPhoneNumber(PhoneNumber);
				

				break;
			} else {
				System.out.println("Invalid phone number");
			}
		}

		while (true) {
			System.out.println("Please enter mail id ");

			email = in.next();

			if (ida.validateMailId(email)) {
				doctorAppointment.setEmail(email);
				
				break;
			} else {
				System.out.println("Invalid mail id");
			}
		}

		while (true) {
			System.out.println("Please enter age ");

			age = in.nextInt();
			String Age = Integer.toString(age);

			if (ida.validateAge(Age)) {
				doctorAppointment.setAge(age);
				
				break;
			} else {
				System.out.println("Invalid age");
			}
		}

		while (true) {
			System.out.println("Please enter gender");

			gender = in.next();

			if (ida.validateGender(gender)) {
				doctorAppointment.setGender(gender);
				break;
			} else {
				System.out.println("Invalid gender");
			}
		}
		
		
		
		
		
		
		
		
		while(true) {
			System.out.println("Enter Problem name");
			
			
			// Scanner sc= new Scanner(System.in);
			String s = in.next();
			
			
		 HashMap<String, String> Geeks = new HashMap<>(); 
		  
	        // Adding values to HashMap as ("keys", "values") 
	        Geeks.put("heart", "Dr. Britesh kumar"); 
	        Geeks.put("Gynecology", "Dr. Sharda Singh"); 
	        Geeks.put("Diabetes", "Dr. Heena Khan"); 
	        Geeks.put("ENT", "Dr. Paras mal"); 
	        Geeks.put("Bone", "Dr. Reenuka Kher"); 
	        Geeks.put("Dermatology", "Dr. Kanika Kapoor"); 
	        
	  
	        System.out.println("Testing .isEmpty() method"); 
	  
	        
	        if (!Geeks.isEmpty()) 
	        { 
	            System.out.println("HashMap Geeks is notempty"); 
	  
	            // Accessing the contents of HashMap through Keys 
	         //   System.out.println("GEEKS : " + Geeks.get(s)); 
	            
	            if(!(Geeks.get(s)==null))
	            {
	            	
	            	status = "Approved";
	        		System.out.println("your appointmnet has been confirmed with the Appointment ID: " + ida.getAppointmentId());

	    
				} else {
					status = "DisApproved";

					//System.out.println(key + " : " + table.get(key));
				}
				
				doctorAppointment.setDoctorName(Geeks.get(s));
				doctorAppointment.setAppointmentStatus(status);
									
				
			break;
			}
			
		
ida.addDoctorAppointmentDetails(doctorAppointment);
		
		

		break;
	}
		
	}

	private static void viewAppointment(int appointmentId) {
		try {

			DoctorAppointment doctorAppointment = ida.getAppointmentDetails(appointmentId);

			System.out.println("Patient Name: " + doctorAppointment.getPatientName());
			System.out.println("Appointmen Statust: " + doctorAppointment.getAppointmentStatus());
			System.out.println("Doctor Name: " + doctorAppointment.getDoctorName());
			System.out.println("doctorAppointmentte Of Appointment: " + doctorAppointment.getDateOfAppointment());

		} catch (DoctorsException e) {

			System.out.println("Error  :" + e.getMessage());
		}

	}

}
