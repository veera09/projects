package com.capgemini.doctors.bean;

public class ProblemsBean {

	private String doctorName;
	private String probName;
	
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getProbName() {
		return probName;
	}
	public void setProbName(String probName) {
		this.probName = probName;
	}
	
	
}
