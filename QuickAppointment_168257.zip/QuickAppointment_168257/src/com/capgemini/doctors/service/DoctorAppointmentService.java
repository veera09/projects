package com.capgemini.doctors.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.DoctorsException;

public class DoctorAppointmentService implements IDoctorAppointmentService {
	
	IDoctorAppointmentDao idocapp;

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws DoctorsException {
		
		return idocapp.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int id) throws DoctorsException {
		
		return idocapp.getAppointmentDetails(id);
	}

	
	@Override
	public boolean validatePatientName(String cname) {
		String patterns = "[A-Z][a-z ]{1,20}";
		if (Pattern.matches(patterns, cname)) {
			return true;
		} else {
			return false;
		}

	}
	
	
	
	
	@Override
	public boolean validatePhoneNumber(String PhoneNumber) {
		String patterns1 = "\\d{10}";
		if (Pattern.matches(patterns1, PhoneNumber)) {
			return true;
		} else {

			return false;
		}

	}

	@Override
	public boolean validateAge(String age) {
		String patterns1 = "\\d{1,2}";
		if (Pattern.matches(patterns1, age)) {
			return true;
		} else {

			return false;
		}
	}

	@Override
	public boolean validateMailId(String MailId) {
		String patterns = "[A-Za-z0-9]{1,}[@][A-Za-z0-9.]{1,}";
		if (Pattern.matches(patterns, MailId)) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public boolean validateGender(String gender) {
		if(gender.equalsIgnoreCase("male")||gender.equalsIgnoreCase("female")||gender.equalsIgnoreCase("other")) {
			return true;
		}
		return false;
	}

	/*
	 * @Override public List<String> getProblemNames() throws DoctorsException {
	 * idocapp = new DoctorAppointmentDao(); List<String> problems =
	 * idocapp.getProblemNames(); return problems; }
	 */
	@Override
	public int getAppointmentId() throws DoctorsException {
		idocapp = new DoctorAppointmentDao();
		int appId = idocapp.getAppointmentId();
		return appId;
	}

	/*
	 * @Override public String getDoctorName(String probName) throws
	 * DoctorsException { idocapp = new DoctorAppointmentDao(); String doctor =
	 * idocapp.getDoctorName(probName); return doctor; }
	 * 
	 */
	
	
}
