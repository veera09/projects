package com.cg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bean.CustomerDto;
import com.cg.bean.LoanDto;
import com.cg.exceptions.LoanExceptions;
import com.cg.service.ServiceClass;

public class Main {
	private static Scanner sc;

	public static void main(String[] args) throws LoanExceptions, SQLException {
		sc = new Scanner(System.in);
		System.out.println("XYZ Finance Company Welcomes You");

		startProgram();
	}

	public static void startProgram() throws LoanExceptions {

		String choice;
		String ch;
		while (true) {
			System.out.println("\n Enter your choice");
			System.out.println("1. Register Customer");

			System.out.println("2. Exit");

			choice = sc.next().trim();
			switch (choice) {
			case "1":
				RegisterCustomer();
				break;
			case "2":
				// Exit();

				System.out.println("\n \n Thank u!!!");
				System.exit(0);
				break;
			default:
				System.out.println("Choose valid choice");
				break;
			}

			System.out.println("do u want to apply loan Y/N");

			ch = sc.next();
			switch (ch) {
			case "Y":
				apply();
				break;
			case "N":
				System.out.println("thanku");
				System.exit(0);
				break;
			}

		}
	}

	private static void apply() {
		// TODO Auto-generated method stub
		LoanDto l1 = new LoanDto();
		System.out.println("Enter the loan Amount");
		double loanAmount = sc.nextDouble();
		l1.setLoanAmount(loanAmount);
		System.out.println("loan Amount :" + " " + l1.getLoanAmount());
		System.out.println("Enter the loan Duration");
		int loanDuration = sc.nextInt();
		l1.setDuration(loanDuration);
		System.out.println("loan Duration :" + " " + l1.getDuration());

	}

	private static void RegisterCustomer() throws LoanExceptions {
		// TODO Auto-generated method stub
		ServiceClass s1 = new ServiceClass();
		CustomerDto c1 = new CustomerDto();
		while (true) {
			System.out.println("Enter customer Name");
			String Name = sc.next();

			if (s1.ValidateCustomerName(Name) == true) {
				c1.setCusName(Name);
				System.out.println("customer :" + c1.getCusName());
				break;
			} else {
				System.out.println("invalid customer name");

			}
		}
		while (true) {
			System.out.println("Enter customer mail");
			String mail = sc.next();

			if (s1.ValidateMailId(mail) == true) {
				c1.setEmail(mail);
				System.out.println("mail :" + c1.getEmail());
				break;
			} else {
				System.out.println("invalid customer mail");

			}
		}
		while (true) {
			System.out.println("Enter customer no");
			String phno = sc.next();

			if (s1.ValidatePhoneNumber(phno) == true) {
				c1.setMobile(phno);
				System.out.println("Phno :" + c1.getMobile());
				break;
			} else {
				System.out.println("invalid customer no");

			}
		}
		while (true) {
			System.out.println("Enter customer address");
			String addrs = sc.next();

			if (s1.ValidateAddress(addrs) == true) {
				c1.setAddress(addrs);
				System.out.println("address :" + c1.getAddress());
				break;
			} else {
				System.out.println("invalid customer address");

			}

		}
		s1.InsertCust(c1);
		System.out.println("inserted");

	}
}
