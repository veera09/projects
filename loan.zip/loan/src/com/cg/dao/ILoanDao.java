package com.cg.dao;

import com.cg.bean.CustomerDto;
import com.cg.bean.Loan;
import com.cg.exceptions.LoanExceptions;

public interface ILoanDao {
	public long applyLoan(Loan loan);

	public CustomerDto InsertCust(CustomerDto c1) throws LoanExceptions;
}
