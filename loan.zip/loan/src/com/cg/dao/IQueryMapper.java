package com.cg.dao;

public class IQueryMapper {

	public static final String INSERT_QUERY = "insert into cust_details values(?,?,?,?)";

}
